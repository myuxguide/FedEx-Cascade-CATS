	// create the module and name it scotchApp
	var catsApp = angular.module('catsApp', ['ngRoute']);

	// configure our routes
	catsApp.config(function($routeProvider) {
		$routeProvider
			// Route for Login Page
			.when('/', {
				templateUrl : 'pages/login.html',
				controller : 'loginController'
			})

			// route for the index page
			.when('/index', {
				templateUrl : './index.html',
				controller : 'indexController'
			})

			// route for the Services page
			.when('/services', {
				templateUrl : 'pages/services.html',
				controller  : 'servicesController'
			})
			// route for the Benchmark page
			.when('/benchmark', {
				templateUrl : 'pages/benchMark.html',
				controller  : 'benchmarkController'
			})

			// route for the Data Validation page
			.when('/dataValidation', {
				templateUrl : 'pages/dataValidation.html',
				controller  : 'dataValidationController'
			})

			// route for the Data results page
			.when('/results', {
				templateUrl : 'pages/results.html',
				controller : 'resultsController'
			})

			// route for the configSetup page
			.when('/configSetup', {
				templateUrl : 'pages/confiSetup.html',
				controller  : 'configSetupController'
			})

			.otherwise({ redirectTo: '/' })
	});

	//loginController
	catsApp.controller('loginController', function($scope){
				$scope.loginControlls = $(function(){

					$(".header, .navBar").hide();

					// $scope.username;
					// console.log("username",username);
					// localStorage.setItem('username');

			
			$("#btn_submit").click(function(){
				$(".header, .navBar").show();
			})

			$('body').addClass('loginPage');

			$(".services").addClass('active');
		})
	})

	//indexController
	catsApp.controller('indexController', function($scope){
		$scope.indexController = $(function(){
			// let username = localStorage.getItem('username');
			// $scope.usrname = username;

			$(".navBar a").click(function(){
				$(".navBar a").removeClass("active");
				$(this).addClass("active");
			});
			// END navBar a
	
			$('a[data-toggle="tab"]').on('show.bs.tab', function(e){
				localStorage.setItem('activeTab', $(e.target).attr('href'));
				localStorage.setItem('activeClass', $(e.target).attr('active'));
				localStorage.setItem('activeLink', $(e.target).attr('class'));
				localStorage.setItem('activeLinkClass', $(e.target).attr('active'));
			});
			// END Tab-function

			$(".navBar a").click(function(e) {
				var link = $(this);

				var item = link.parent("li");
				
				if (item.hasClass("active")) {
					item.removeClass("active").children("a").removeClass("active");
				} else {
					item.addClass("active").children("a").addClass("active");
				}

				if (item.children("ul").length > 0) {
					var href = link.attr("href");
					link.attr("href", "#");
					setTimeout(function () { 
					link.attr("href", href);
					}, 300);
					e.preventDefault();
				}
			}).each(function()
			{
				var link = $(this);
				if (link.get(0).href === location.href) {
					link.addClass("active").parents("li").addClass("active");
					return false;
				}
        		});

			//Acá guarda el index al cual corresponde la tab. Lo podés ver en el dev tool de chrome.
			var activeTab = localStorage.getItem('activeTab');			
			var activeClass = localStorage.getItem('activeClass');
			var activeLink = localStorage.getItem('activeLink');
			var activeLinkClass = localStorage.getItem('activeLinkClass');

			console.log(activeTab + activeClass + activeLink + activeLinkClass);

			if (activeTab) {
				$('a[href="' + activeTab + '"]').tab('show');
					$(".navBar a").click(function(){
					$(".navBar a").removeClass("active");
					$(this).addClass("active");
				})		  
			}
		})
	})
	// END indexController

	//servicesController
	catsApp.controller('servicesController', function($scope) {
		$scope.showDataFunc = $(function(){
			$(".header, .navBar").slideDown();

			// Sidebar ShowHide Function
			$(".sidebar ul li a").click(function(){
				$(".sidebar ul li a").removeClass("active");
				$(this).addClass("active");
			})

			$(".serviceInfo").dataTable({
				"initComplete": function(settings, json) {
					$('body').find('.dataTables_scrollBody').addClass("scrollbar");
				},	
				"scrollY":       '32vh',
				"scrollCollapse": true,
				"paging":         true,	
				"bDestroy": true,				
				ajax: "api/serviceData.txt",
				columns: [
					{ data: "id" },
					{ data: "servName" },
					{ data: "TestLevel" },
					{ data: "TestType" },					
					{ data: "Timestamp" },
					{ data: "Status" },
					{ 
						data: "myData",
						"render": function ( data) {
							return '<a class="btn btn-link downloadFile p-0 pr-4" href="'+data+'"> ' + data + ' </a>';
						}
					}
				]
			});			
		
			$(".nav-link").click(function(){
				$(".navBar").css({
					'visibility' : 'visible'
				})
			})
			
			$("#showResults").click(function(){
				$(".showFetchData").fadeIn();
			})
			
			$(".btnCheck").click(function(){
				$(".text-success").fadeIn();
			})
		})
		// END jQuery Function
	});

	//Scope for benchmarkController
	catsApp.controller('benchmarkController', function($scope) {
		$scope.myFunction = $(function(){
				// Sidebar ShowHide Function
			$(".sidebar ul li a").click(function(){
				$(".sidebar ul li a").removeClass("active");
				$(this).addClass("active");
			})

			$(".benchMarkInfo").dataTable({
				"initComplete": function(settings, json) {
					$('body').find('.dataTables_scrollBody').addClass("scrollbar");
				},
				"scrollY":       '32vh',
				"scrollCollapse": true,
				"paging":         true,	
				"bDestroy": true,
				ajax: "api/benchMarkData.txt",
				columns: [
					{ data: "id" },
					{ data: "servName" },
					{ data: "TestLevel" },
					{ data: "TestType" },					
					{ data: "Timestamp" },
					{ data: "Status" },
					{ 
						data: "DownloadFile",
						"render": function ( data) {
							return '<a class="btn btn-link downloadFile p-0 pr-4" href="'+data+'"> ' + data + ' </a>';
						}
					}
				]
			});

			$(".nav-link").click(function(){
				$(".navBar").css({
					'visibility' : 'visible'
				})
			})

			$("#showResults").click(function(){
				$(".showFetchData").fadeIn();
			})

			$(".dropDownLink").click(function(){
				$(".checkLists").slideDown(250);
			})
			$(document).mouseup(function(e) 
			{
				var container = $(".checkLists");
				// if the target of the click isn't the container nor a descendant of the container
				if (!container.is(e.target) && container.has(e.target).length === 0) 
				{
					container.slideUp(250);
				}
			});

			let $checkboxes = $('input[class="chBox"]');
			$checkboxes.change(function(){
				let countCheckedCheckboxes = $checkboxes.filter(':checked').length;				
				$('.dropDownLink').text( countCheckedCheckboxes + " Selected");
			});
		})
	});
	// END Benchmark Controller

	//dataValController
	catsApp.controller('dataValidationController', function($scope) {
		$scope.myFunction = $(function(){
			// alert("dataValidationController...");
		});
	});
	// END dataValController

	//resultsController
	catsApp.controller('resultsController', function($scope) {
		$scope.myFunction = $(function(){

			$("#displayTable").hide();
			$("#showMap").click(function(){
				$("#displayMap").show();
				$("#displayTable").hide();
			})

			$("#showTable").click(function(){
				$("#displayMap").hide();
				$("#displayTable").show();
			})

			$(".resultInfo_map").dataTable({
				"initComplete": function(settings, json) {
					$('body').find('.dataTables_scrollBody').addClass("scrollbar");
				},	
				"scrollY":       '37vh',
				"scrollCollapse": true,
				"paging":         true,	
				"bDestroy": true,
				ajax: "api/resultData_map.txt",
				columns: [
					{ data: 'releases' } ,
					{ data: 'environments'},
					{ data: 'unit' },
					{ data: 'regression' },
					{ data: 'load' },
					{ data: 'benchmark' },
					{ data: 'status' }					
				]
			})

			$(".resultInfo_table").dataTable({
				"initComplete": function(settings, json) {
					$('body').find('.dataTables_scrollBody').addClass("scrollbar");
				},	
				"scrollY":       '37vh',
				"scrollCollapse": true,
				"paging":         true,	
				"bDestroy": true,
				ajax: "api/resultData_table.txt",
				columns: [
					{ data: 'releases' } ,
					{ data: 'environments'},
					{ data: 'unit' },
					{ data: 'regression' },
					{ data: 'load' },
					{ data: 'benchmark' },
					{ data: 'status' }					
				]
			})
		});
	});
	// END resultsController

	// mapController
	catsApp.controller('mapController', function($scope){
		$scope.myFunction = $(function(){
			$(".resultInfo_map").dataTable({
				"initComplete": function(settings, json) {
					$('body').find('.dataTables_scrollBody').addClass("scrollbar");
				},	
				"scrollY":       '37vh',
				"scrollCollapse": true,
				"paging":         true,	
				"bDestroy": true,
				ajax: "api/resultData_map.txt",
				columns: [
					{ data: 'releases' } ,
					{ data: 'environments'},
					{ data: 'unit' },
					{ data: 'regression' },
					{ data: 'load' },
					{ data: 'benchmark' },
					{ data: 'status' }					
				]
			})
		})
	})

	// configSetupController
	catsApp.controller('configSetupController', function($scope){
		$scope.myFunction = $(function(){
			$(".configSetupInfo").dataTable({
				"initComplete": function(settings, json) {
					$('body').find('.dataTables_scrollBody').addClass("scrollbar");
				},	
				"scrollY":       '37vh',
				"scrollCollapse": true,
				"paging":         true,							
				"bDestroy": true,
				ajax: "api/configSetupData.txt",
				columns: [
					{ data: "req" },
					{ data: "res" },
					{ data: "ServiceName" },				
					{ data: "testLevel" },
					{ data: "testUrl" }
				]
			});

			$(".sidebarHeading").click(function(){
				$(".configMenu").toggle();
				$(this).toggleClass("sidebarHeading_active")
			})

			$("#showResults").click(function(){
				$(".showFetchData").slideDown();
			});
		})
	})
	// END configSetupController