	// create the module and name it scotchApp
	var catsApp = angular.module('catsApp', ['ngRoute']);

	// configure our routes
	catsApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'pages/services.html',
				controller  : 'servicesController'
			})

			.when('/login', {
				templateUrl : 'pages/login.html',
				controller : 'loginController'
			})

			// route for the about page
			.when('/benchmark', {
				templateUrl : 'pages/benchMark.html',
				controller  : 'benchmarkController'
			})

			// route for the contact page
			.when('/dataValidation', {
				templateUrl : 'pages/dataValidation.html',
				controller  : 'dataValidationController'
			})

			.when('/results', {
				templateUrl : 'pages/results.html',
				controller : 'resultsController'

			})

			// route for the contact page
			.when('/configSetup', {
				templateUrl : 'pages/confiSetup.html',
				controller  : 'configSetupController'
			})
	});

	//servicesController
	catsApp.controller('servicesController', function($scope) {
		$scope.showDataFunc = $(function(){
			$(".serviceDataTable table").dataTable();
			
			$("#showResults").click(function(){
                $(".showFetchData").fadeIn();
			})
			$(".btnCheck").click(function(){
				$(".text-success").fadeIn();
			})
		})
	});

	//Scope for Benchmark.html
	catsApp.controller('benchmarkController', function($scope) {
		//$scope.message = 'In Progress...';
		$scope.myFunction = $(function(){
			$("#showResults").click(function(){
				$(".showFetchData").fadeIn();
			})

			$(".dropDownLink").click(function(){
				$(".checkLists").slideToggle();
			})

			let $checkboxes = $('input[class="chBox"]');
			$checkboxes.change(function(){
				let countCheckedCheckboxes = $checkboxes.filter(':checked').length;				
				$('.dropDownLink').text( countCheckedCheckboxes + " Selected");
			}); 

			$(".chValues").click(function(){
				$(".checkLists").hide();
			})  
		})
	});
	// END Benchmark Controller

	catsApp.controller('dataValidationController', function($scope) {
		$scope.message = 'Data Validation Module in Progress...! ';
	});

	catsApp.controller('resultsController', function($scope) {
		$scope.message = 'Results Module in Progress...! ';
	});

	catsApp.controller('configSetupController', function($scope){
		$scope.myFunction = $(function(){
			$("#showResults").click(function(){
				$(".showFetchData").slideDown();
			})
		})
	})