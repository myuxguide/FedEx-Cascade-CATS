/*Global API File*/
function serviceController($scope,$http) {
   var serviceData = "api/serviceData.txt";
   
   $http.get(serviceData).then( function(response) {
      $scope.services = response.data;
   });
}