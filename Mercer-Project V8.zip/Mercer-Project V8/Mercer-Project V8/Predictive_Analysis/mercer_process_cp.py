# -*- coding: utf-8 -*-
"""
Created on Wed Dec  5 10:51:26 2018

@author: SR5043206
"""
#import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc
import pickle
from sklearn.preprocessing import LabelEncoder
from IPython.core.interactiveshell import InteractiveShell

def mercer_etv(filename, enhance_perc):
    
    InteractiveShell.ast_node_interactivity = "all"
    pd.set_option('precision', 5)
    pd.options.display.float_format = '{:.2f}'.format
    
    #laod pickle file ( model )
    with open('my_gbm_model_3.5.pkl', 'rb') as file:
                clf_gbm = pickle.load(file) 
                
    df_test = pd.read_csv(filename, thousands=',')
    print(df_test.dtypes)
    
    df_450 = df_test.copy()
    df_450 = df_450[df_450['pred'] == 0]
    df_450.drop('pred',axis=1,inplace=True)
    df_450.drop('score',axis=1,inplace=True)
    
    df_450.columns = df_450.columns.str.strip().str.lower().str.replace(' ', '_')
    df_450.columns = df_450.columns.str.strip().str.lower().str.replace(',', '')
    
    
    #df_450 = enhance_stv(enhance_perc)
    df_450['increase_offered'] = df_450['standard_tv'].apply(lambda x:x*enhance_perc/100)
    
    y_pred=clf_gbm.predict(df_450)
    y_pred_prob = y_pred.copy()
    
    #convert into binary values
    for i in range(0,len(df_450)):
        if y_pred[i]>=.6:       # setting threshold to .6
           y_pred[i]=1
        else:  
           y_pred[i]=0
      
    pd.options.display.float_format = '{:.4f}'.format
    pred_prob = pd.Series(y_pred_prob, index=df_450.index)
    #pred_prob = pred_prob.apply(lambda x:x*100)
    df_450['score'] = y_pred_prob
    
    pred = pd.Series(y_pred,index=df_450.index)
    pred.apply(int)
    df_450['pred'] = pred
        
    df_450[df_450['pred'] == 0].to_csv("Mercer_Rejected_"+str(enhance_perc)+".csv",index=False);    
    df_450[df_450['pred'] == 1].to_csv("Mercer_Accepted_"+str(enhance_perc)+".csv",index=False);
    return df_450
