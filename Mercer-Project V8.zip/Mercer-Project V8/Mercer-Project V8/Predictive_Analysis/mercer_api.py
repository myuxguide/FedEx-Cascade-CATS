# -*- coding: utf-8 -*-
"""
Created on Wed Dec  5 16:16:41 2018

@author: EC5048851
"""

import os
from flask import Flask, render_template, flash, request, jsonify
from flask_cors import CORS, cross_origin
import pandas as pd
import mercer_process_cp
import math

app = Flask(__name__)
CORS(app, support_credentials=True)
app.config['SECRET_KEY'] =  os.urandom(24)


@app.route("/", methods=['POST'])
@cross_origin(supports_credentials=True)
def translate_api():
    request_dict = request.json
    filename = request_dict['filename']
    enhance_perc = request_dict['enhancement']
    print ("filename : ",filename)
    print ("enhance_perc : ",enhance_perc)
    
    
    result  =  mercer_process_cp.mercer_etv(filename,enhance_perc)
    print(result.columns)
    
    df_450 = result.copy()
    
    df = pd.DataFrame()
    df['corp'] = df_450[df_450['pred'] == 1]['standard_tv'].apply(lambda x:(x+(enhance_perc)*.01*x))
    
    fund_corpus = (sum(df_450['standard_tv'].values)*1)
    fund_etv = sum(df_450['increase_offered'].values) + fund_corpus
    
    len_df_450 = len(df_450)
    accepted = len(df_450[df_450['pred'] == 1])
    rejected = len(df_450[df_450['pred'] == 0])
    corp_exhausted = sum(df['corp'].values) 
    corp_remaining = (fund_etv - corp_exhausted)
    
    total_asst_rel =  (sum(df_450[df_450['pred'] == 1]['standard_tv'].values) +
    sum(df_450[df_450['pred'] == 1]['increase_offered'].values))
    total_tp_liab = sum(df_450[df_450['pred'] == 1]['tp_liability'].values) 
    total_buyout_liab = sum(df_450[df_450['pred'] == 1]['buyout_liability'].values)
    total_stdtv_liab = sum(df_450[df_450['pred'] == 1]['standard_tv'].values) 
    saving_tp_liab = total_tp_liab - total_asst_rel
    saving_buyout_liab = total_buyout_liab - total_asst_rel
    enhancement_paid = total_asst_rel - total_stdtv_liab
    
    
    data_list = []
    for index, row in result.iterrows():
        data_dict = {}
        #1
        data_dict['accounting_liability'] = row['accounting_liability']
        #2
        data_dict['age_at_offer'] = row['age_at_offer']
        #3
        data_dict['buyout_liability'] = row['buyout_liability']
        #4
        data_dict['increase_offered'] = row['increase_offered']
        #5
        data_dict['retirement_quote'] = row['retirement_quote']
        #6
        data_dict['standard_tv'] = row['standard_tv']
        #7
        data_dict['tp_liability'] = row['tp_liability']
        
        #8
        data_dict['gender'] = row['gender']
        #9
        data_dict['month_of_offer'] = row['month_of_offer']
        #10
        data_dict['nuts3'] = row['nuts3']
        #11
        data_dict['score'] = row['score']
        #12
        data_dict['pred'] = row['pred']
        #13
        data_dict['b.6g_gross_disposable_income'] = row['b.6g_gross_disposable_income']

        
        data_list.append(data_dict)
        if data_list:
            responseData = data_list
            my_parity = 'Success'
        else:
            responseData = []
            my_parity = 'Failure'
            
        
        response = {'status': my_parity,
                    'fileResponse' : responseData, 
                    'len_df_450' : len_df_450,
                    'fund_corpus': int(fund_corpus),
                    'fund_exhausted': int(corp_exhausted),
                    'accepted': accepted,
                    'rejected': rejected,
                    'corp_remaining': int(corp_remaining),
                    'total_asst_rel': int(total_asst_rel),
                    'total_tp_liab': int(total_tp_liab),
                    'total_buyout_liab': int(total_buyout_liab),
                    'total_stdtv_liab': int(total_stdtv_liab),
                    'saving_tp_liab': int(saving_tp_liab),
                    'saving_buyout_liab': int(saving_buyout_liab),
                    'enhancement_paid': int(enhancement_paid)
                    }
        print(response)
        
        return jsonify(response)

if __name__ == "__main__":
    app.run(port=5000)
    
    
    
    
    
    
    
    